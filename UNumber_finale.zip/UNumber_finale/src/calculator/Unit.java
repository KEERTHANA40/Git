package calculator;

//import calculator.Unit;

public class Unit {
		//Variables are declared here.
	int unitSpecifier;
	String unitName;
	private String metricMultiplier = "1";
	int resultUS;
	
	String[] unitList = {"-- no unit selected --",				//UnitList is a string array contains all the units used in this calculator.
			"meter", "kilometer", "feet",        //3
			"seconds", "minutes", "hours", 		//6
			"grams", "pounds", "kilograms",			//9
			"mps", "kmph",				//11
			"mps2", "kmph2",		//13
			"Newton", "Dyne",		//15
			"km3s-2",	//16
			"m2","km2","feet2",		//19
			"kg.m.s-1", "g.cm.s-1"," ", "m3","km3", "sec2","kmps", "days" //27
			};
	
	//This is a default constructor which takes no arguments.
	public Unit() {
		unitSpecifier = 0;					//It sets unitSpecifier and unitName to 0.
		unitName = unitList[0];
	}
	
	//This is a parameter constructor which takes unitSpecifier as argument.
	public Unit (int unitSpecifier) {
		this.unitSpecifier = unitSpecifier;				//It sets unitSpecifier and unitName to the value taken by the function.
		this.unitName = unitList[unitSpecifier];
	}
	
	/* *
	 * Setters and getters
	 * */
	int getUnitSpecifier() {
		return this.unitSpecifier;		//This function returns the unitSpecifier
	}
	
	String getUnit() {
		return unitList[unitSpecifier];	//This function returns the unitList array index value needed.
	}
	
	void setUnitSpecifier(int newUnitSpecifier) {
		this.unitSpecifier = newUnitSpecifier;		//Sets the unitSpecifier value to the value taken in the function.
	}
	
	/* * 
	 * getters
	 * */
	public String getMetricMultiplier() {
		return this.metricMultiplier;
	}
	
	/* *
	 * toString()
	 * */
	public String toString() {
		return unitName;				//converts unitName in string format.
	}
	
	/* *
	 * check if valid gives a boolean telling the units can be operated directly or not
	 * */
	boolean checkIfValidForAddition(Unit that) {
		System.out.println(this.unitSpecifier+" "+that.unitSpecifier);			
		if(this.unitSpecifier==0 && that.unitSpecifier==0)				//This function checks whether the unitSpecifier is valid for the function or not.
		{
			return true;
		}
		
		switch(this.unitSpecifier) {
		case 1:
			switch(that.unitSpecifier) {
			case 1: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 1; return true;
			case 2: this.metricMultiplier = "1.0"; that.metricMultiplier = "1000.0"; resultUS = 1; return true;
			case 3: this.metricMultiplier = "3.28084"; that.metricMultiplier = "1.0"; resultUS = 3; return true;
			default: return false;
			}
		case 2:
			switch(that.unitSpecifier) {
			case 1: this.metricMultiplier = "1000.0"; that.metricMultiplier = "1.0"; resultUS = 1; return true;
			case 2: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 2; return true;
			case 3: this.metricMultiplier = "3280.84"; that.metricMultiplier = "1.0"; resultUS = 3; return true;
			default: return false;
			}
		case 3:
			switch(that.unitSpecifier) {
			case 1: this.metricMultiplier = "1.0"; that.metricMultiplier = "3.2804"; resultUS = 3; return true;
			case 2: this.metricMultiplier = "1.0"; that.metricMultiplier = "3280.84"; resultUS = 3; return true;
			case 3: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 3; return true;
			default: return false;
			}
		case 4:
			switch(that.unitSpecifier) {
			case 4: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 4; return true;
			case 5: this.metricMultiplier = "1.0"; that.metricMultiplier = "60.0"; resultUS = 4; return true;
			case 6: this.metricMultiplier = "1.0"; that.metricMultiplier = "3600.0"; resultUS = 4; return true;
			default: return false;
			}
		case 5:
			switch(that.unitSpecifier) {
			case 4: this.metricMultiplier = "60.0"; that.metricMultiplier = "1.0"; resultUS = 4; return true;
			case 5: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 5; return true;
			case 6: this.metricMultiplier = "1.0"; that.metricMultiplier = "60.0"; resultUS = 5; return true;
			default: return false;
			}
		case 6:
			switch(that.unitSpecifier) {
			case 4: this.metricMultiplier = "3600.0"; that.metricMultiplier = "1.0"; resultUS = 4; return true;
			case 5: this.metricMultiplier = "60.0"; that.metricMultiplier = "1.0"; resultUS = 5; return true;
			case 6: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 6; return true;
			default: return false;
			}
		case 7:
			switch(that.unitSpecifier) {
			case 7: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 7; return true;
			case 8: this.metricMultiplier = "1.0"; that.metricMultiplier = "453.592"; resultUS = 7; return true;
			case 9: this.metricMultiplier = "1.0"; that.metricMultiplier = "1000.0"; resultUS = 7; return true;
			default: return false;
			}
		case 8:
			switch(that.unitSpecifier) {
			case 7: this.metricMultiplier = "453.592"; that.metricMultiplier = "1.0"; resultUS = 7; return true;
			case 8: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 8; return true;
			case 9: this.metricMultiplier = "1.0"; that.metricMultiplier = "2.20462"; resultUS = 8; return true;
			default: return false;
			}
		case 9:
			switch(that.unitSpecifier) {
			case 7: this.metricMultiplier = "1000.0"; that.metricMultiplier = "1.0"; resultUS = 7; return true;
			case 8: this.metricMultiplier = "2.20462"; that.metricMultiplier = "1.0"; resultUS = 8; return true;
			case 9: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 9; return true;
			default: return false;
			}
		case 10:
			switch(that.unitSpecifier) {
			case 10: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 10; return true;
			case 11: this.metricMultiplier = "1.0"; that.metricMultiplier = "0.27777777777"; resultUS = 10; return true;
			default: return false;
			}
		case 11:
			switch(that.unitSpecifier) {
			case 10: this.metricMultiplier = "0.27777777777"; that.metricMultiplier = "1.0"; resultUS=10; return true;
			case 11: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 11; return true;
			default: return false;
			}
		case 12:
			switch(that.unitSpecifier) {
			case 12: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 12; return true;
			case 13: this.metricMultiplier = "1.0"; that.metricMultiplier = "0.00007716049"; resultUS = 12; return true;
			default: return false;
			}
		case 13:
			switch(that.unitSpecifier) {
			case 12: this.metricMultiplier = "0.00007716049"; that.metricMultiplier = "1.0"; resultUS=12; return true;
			case 13: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 13; return true;
			default: return false;
			}
		case 14:
			switch(that.unitSpecifier) {
			case 14: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 14; return true;
			case 15: this.metricMultiplier = "100000"; that.metricMultiplier = "1.0"; resultUS = 15; return true;
			default: return false;
			}
		case 15:
			switch(that.unitSpecifier) {
			case 14: this.metricMultiplier = "1.0"; that.metricMultiplier = "100000"; resultUS=15; return true;
			case 15: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 15; return true;
			default: return false;
			}
		case 16:
			switch(that.unitSpecifier) {
			case 16: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 16;return true;
			default: return false;
			}
		case 17:
			switch(that.unitSpecifier) {
			case 17: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 23;return true;
			case 18: this.metricMultiplier = "1.0"; that.metricMultiplier = "1000000000"; resultUS = 23;return true;
			default: return false;
			}
		case 18:
			switch(that.unitSpecifier) {
			case 17: this.metricMultiplier = "1000000000"; that.metricMultiplier = "1.0"; resultUS = 23;return true;
			case 18: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 24;return true;
			default: return false;
			}
		case 19:
			switch(that.unitSpecifier) {
			case 19: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 17;return true;
			case 20: this.metricMultiplier = "1.0"; that.metricMultiplier = "1000000"; resultUS = 17;return true;
			default: return false;
			}
		case 20:
			switch(that.unitSpecifier) {
			case 19: this.metricMultiplier = "1000000"; that.metricMultiplier = "1.0"; resultUS = 17;return true;
			case 20: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 18;return true;
			default: return false;
			}
		case 22:
			switch(that.unitSpecifier) {
			case 22: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 26;return true;
			default: return false;
			}
		default: return false;
		}
	}
	
	boolean checkIfValidForSubtraction(Unit that) {
		return checkIfValidForAddition(that);
	}
	
	boolean checkIfValidForMultiplication(Unit that) {
		System.out.println("+++++++++++++++++++++++++\n"+this.unitSpecifier+" "+that.unitSpecifier);
		switch(this.unitSpecifier) {
		case 0: return true;
		case 1:
			switch(that.unitSpecifier) {
			case 1: this.metricMultiplier = "1.0" ; that.metricMultiplier = "1.0"; resultUS = 17; return true;
			case 2: this.metricMultiplier = "1.0"; that.metricMultiplier = "1000.0"; resultUS = 17; return true;
			case 3: this.metricMultiplier = "3.28084"; that.metricMultiplier = "1.0"; resultUS = 19; return true;
			case 19: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 23; return true;
			case 20: this.metricMultiplier = "1.0"; that.metricMultiplier = "1000000"; resultUS = 23; return true;
			default: return false;
			}
		case 2:
			switch(that.unitSpecifier) {
			case 1: this.metricMultiplier = "1000.0" ; that.metricMultiplier = "1.0"; resultUS = 17; return true;
			case 2: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 18; return true;
			case 3: this.metricMultiplier = "3280.84"; that.metricMultiplier = "1.0"; resultUS = 19; return true;
			case 19: this.metricMultiplier = "1000"; that.metricMultiplier = "1.0"; resultUS = 23; return true;
			case 20: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 24; return true;
			default: return false;
			}
		case 3:
			switch(that.unitSpecifier) {
			case 1: this.metricMultiplier = "1.0" ; that.metricMultiplier = "3.28084"; resultUS = 19; return true;
			case 2: this.metricMultiplier = "1.0"; that.metricMultiplier = "3280.84"; resultUS = 19; return true;
			case 3: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 19; return true;
			default: return false;
			}
		case 4:
			switch(that.unitSpecifier) {
			case 10: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 1; return true;
			case 11: this.metricMultiplier = "0.00027777777"; that.metricMultiplier = "1.0"; resultUS = 2; return true;
			case 12: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 10; return true;
			case 13: this.metricMultiplier = "0.00027777777"; that.metricMultiplier = "1.0"; resultUS = 11; return true;
			case 14: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 20; return true;
			case 15: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 21; return true;
			default: return false;
			}
		case 5:
			switch(that.unitSpecifier) {
			case 10: this.metricMultiplier = "60.0"; that.metricMultiplier = "1.0"; resultUS = 1; return true;
			case 11: this.metricMultiplier = "0.01666666666"; that.metricMultiplier = "1.0"; resultUS = 2; return true;
			case 12: this.metricMultiplier = "60.0"; that.metricMultiplier = "1.0"; resultUS = 10; return true;
			case 13: this.metricMultiplier = "0.01666666666"; that.metricMultiplier = "1.0"; resultUS = 11; return true;
			case 14: this.metricMultiplier = "60.0"; that.metricMultiplier = "1.0"; resultUS = 20; return true;
			case 15: this.metricMultiplier = "60.0"; that.metricMultiplier = "1.0"; resultUS = 21; return true;
			default: return false;
			}
		case 6:
			switch(that.unitSpecifier) {
			case 10: this.metricMultiplier = "3600.0"; that.metricMultiplier = "1.0"; resultUS = 1; return true;
			case 11: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 2; return true;
			case 12: this.metricMultiplier = "3600.0"; that.metricMultiplier = "1.0"; resultUS = 10; return true;
			case 13: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 11; return true;
			case 14: this.metricMultiplier = "3600.0"; that.metricMultiplier = "1.0"; resultUS = 20; return true;
			case 15: this.metricMultiplier = "3600.0"; that.metricMultiplier = "1.0"; resultUS = 21; return true;
			default: return false;
			}
		case 10:
			switch(that.unitSpecifier) {
			case 4: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 1; return true;
			case 5: this.metricMultiplier = "1.0"; that.metricMultiplier = "60.0"; resultUS = 1; return true;
			case 6: this.metricMultiplier = "1.0"; that.metricMultiplier = "3600.0"; resultUS = 1; return true;
			default: return false;
			}
		case 11:
			switch(that.unitSpecifier) {
			case 4: this.metricMultiplier = "1.0"; that.metricMultiplier = "0.00027777777"; resultUS = 2; return true;
			case 5: this.metricMultiplier = "1.0"; that.metricMultiplier = "0.01666666666"; resultUS = 2; return true;
			case 6: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 2; return true;
			default: return false;
			}
		case 12:
			switch(that.unitSpecifier) {
			case 4: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 10; return true;
			case 5: this.metricMultiplier = "1.0"; that.metricMultiplier = "60.0"; resultUS = 10; return true;
			case 6: this.metricMultiplier = "1.0"; that.metricMultiplier = "3600.0"; resultUS = 10; return true;
			default: return false;
			}
		case 13:
			switch(that.unitSpecifier) {
			case 4: this.metricMultiplier = "1.0"; that.metricMultiplier = "0.00027777777"; resultUS = 11; return true;
			case 5: this.metricMultiplier = "1.0"; that.metricMultiplier = "0.01666666666"; resultUS = 11; return true;
			case 6: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 11; return true;
			default: return false;
			}
		case 14:
			switch(that.unitSpecifier) {
			case 4: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 20; return true;
			case 5: this.metricMultiplier = "1.0"; that.metricMultiplier = "60.0"; resultUS = 20; return true;
			case 6: this.metricMultiplier = "1.0"; that.metricMultiplier = "3600.0"; resultUS = 20; return true;
			default: return false;
			}
		case 15:
			switch(that.unitSpecifier) {
			case 4: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 21; return true;
			case 5: this.metricMultiplier = "1.0"; that.metricMultiplier = "60.0"; resultUS = 21; return true;
			case 6: this.metricMultiplier = "1.0"; that.metricMultiplier = "3600.0"; resultUS = 21; return true;
			default: return false;
			}
		default: return false;
		}
	}
	
	boolean checkIfValidForDivision(Unit that) {
		System.out.println("+++++++++++++++++++++++++\n"+this.unitSpecifier+" "+that.unitSpecifier);
		switch(this.unitSpecifier) {
		case 0: return true;
		case 1:
			switch(that.unitSpecifier) {
			case 1:this.metricMultiplier="1.0";that.metricMultiplier="1.0";resultUS=22;return true;
			case 2:this.metricMultiplier="1.0";that.metricMultiplier="1000.0";resultUS=22;return true;
			case 3:this.metricMultiplier="3.28084";that.metricMultiplier="1.0";resultUS=22;return true;
			case 4: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 10; return true;
			case 5: this.metricMultiplier = "1.0"; that.metricMultiplier = "60.0"; resultUS = 10; return true;
			case 6: this.metricMultiplier = "0.001"; that.metricMultiplier = "1.0"; resultUS = 11; return true;
			default: return false;
			}
		case 2:
			switch(that.unitSpecifier) {
			case 0: this.metricMultiplier="1.0";that.metricMultiplier="1.0";resultUS=2;return true;
			case 2:this.metricMultiplier="1.0";that.metricMultiplier="1.0";resultUS=22;return true;
			case 1:this.metricMultiplier="1000.0";that.metricMultiplier="1.0";resultUS=22;return true;
			case 3:this.metricMultiplier="3280.84";that.metricMultiplier="1.0";resultUS=22;return true;
			case 4: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 26; return true;
			case 5: this.metricMultiplier = "1.0"; that.metricMultiplier = "0.01666666666"; resultUS = 11; return true;
			case 6: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 11; return true;
			default: return false;
			}
		case 3:
			switch(that.unitSpecifier) {
			case 2:this.metricMultiplier="1.0";that.metricMultiplier="3280.84";resultUS=22;return true;
			case 1:this.metricMultiplier="1.0";that.metricMultiplier="3.28084";resultUS=22;return true;
			case 3:this.metricMultiplier="1.0";that.metricMultiplier="1.0";resultUS=22;return true;
			case 4: this.metricMultiplier = "0.3048"; that.metricMultiplier = "1.0"; resultUS = 10; return true;
			case 5: this.metricMultiplier = "0.3048"; that.metricMultiplier = "60.0"; resultUS = 10; return true;
			case 6: this.metricMultiplier = "0.3048"; that.metricMultiplier = "3600.0"; resultUS = 10; return true;
			default: return false;
			}
			
		case 4:
			switch(that.unitSpecifier) {
			case 23:this.metricMultiplier="1.0";that.metricMultiplier="1.0";resultUS=27;return true;
			default: return false;
			}
		case 10:
			switch(that.unitSpecifier) {
			case 10:this.metricMultiplier="1.0";that.metricMultiplier="1.0";resultUS=22;return true;
			case 4: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 12; return true;
			case 5: this.metricMultiplier = "1.0"; that.metricMultiplier = "60.0"; resultUS = 12; return true;
			case 6: this.metricMultiplier = "1.0"; that.metricMultiplier = "3600.0"; resultUS = 12; return true;
			default: return false;
			}
		case 11:
			switch(that.unitSpecifier) {
			case 11:this.metricMultiplier="1.0";that.metricMultiplier="1.0";resultUS=22;return true;
			case 4: this.metricMultiplier = "1.0"; that.metricMultiplier = "0.00027777777"; resultUS = 13; return true;
			case 5: this.metricMultiplier = "1.0"; that.metricMultiplier = "0.01666666666"; resultUS = 13; return true;
			case 6: this.metricMultiplier = "1.0"; that.metricMultiplier = "1.0"; resultUS = 13; return true;
			default: return false;
			}
			
		case 18:
			switch(that.unitSpecifier) {
			case 16:this.metricMultiplier="1.0";that.metricMultiplier="1.0";resultUS=27;return true;
			default: return false;
			}
		
		default: return false;
		}
	}
	
	boolean checkIfValidForSquareroot(Unit that) {
		System.out.println("+++++++++++++++++++++++++\n"+this.unitSpecifier+" "+that.unitSpecifier);
		switch(this.unitSpecifier) {
		case 0: return true;
		
			
		case 19:
			switch(that.unitSpecifier) {
			case 0:this.metricMultiplier="1.0";that.metricMultiplier="1.0";resultUS=1;return true;
			default: return false;
			}
		case 20:
			switch(that.unitSpecifier) {
			case 0:this.metricMultiplier="1.0";that.metricMultiplier="1.0";resultUS=2;return true;
			default: return false;
			}
			
		case 21:
			switch(that.unitSpecifier) {
			case 0:this.metricMultiplier="1.0";that.metricMultiplier="1.0";resultUS=4;return true;
			default: return false;
			}
		
		default: return false;
		}
	}
	
	/* *
	 * get result unit returns resultant unit after performing the operation
	 * */
	Unit getResultantUnitAfterAddition(Unit that) {
		return new Unit(resultUS);
	}
	
	Unit getResultantUnitAfterSubtraction(Unit that) {
		return new Unit(resultUS);
	}
	
	Unit getResultantUnitAfterMultiplication(Unit that) {
		return new Unit(resultUS);
	}
	
	Unit getResultantUnitAfterDivision(Unit that) {
		return new Unit(resultUS);
	}
}